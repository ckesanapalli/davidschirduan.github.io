---------------MYTHIC MORTALS-----------
V. 3.1

Please purchase the Core Rules for advice on making your own Adventures and Mats.
Find it at mythicmortals.com
-----------Fonts---------------------
For the adventures you'll want to download Lato and PT Serif in all weights to use this properly. Both are free:
https://www.google.com/fonts#UsePlace:use/Collection:Lato 
https://www.google.com/fonts#UsePlace:use/Collection:PT+Serif 

The primary font used for the Player Mats is Segoe UI

The title font is Regula Old Face

-------------License----------------
Mythic Mortals is released under the CC-BY 4.0 License.

That means you can make your own hacks, games, supplements, 
and anything else based on Mythic Mortals, so long as you creadit me.
You can even sell your creations for full profit. 

If you have any questions, or would like some feedback, please shoot me an email:

davidschirduan@gmail.com